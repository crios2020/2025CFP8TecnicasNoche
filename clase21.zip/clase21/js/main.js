var caja1=document.getElementById("caja1")

function style(color){
    return "color: "+color+"; "+
            "background-color:lightblue; "+
            "padding: 10px; "+
            "text-align: center; "+
            "border-radius: 20px; "
}

function cargar(){
    //caja1.innerHTML="<h1>Hola a todos!</h1>"
    caja1.innerHTML="<p>"+getFecha()+"</p>"
    caja1.style=style("white")
}

function rojo(){
    caja1.style=style("red")
}

function verde(){
    caja1.style=style("green")
}

function azul(){
    caja1.style=style("blue")
}